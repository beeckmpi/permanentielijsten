
<?php print_r($locaties)?>