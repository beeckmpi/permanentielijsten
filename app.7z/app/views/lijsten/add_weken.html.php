
<?php print_r($weken)?>