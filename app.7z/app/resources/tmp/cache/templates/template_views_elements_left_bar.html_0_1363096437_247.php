
<ul class="nav nav-list">	
	<?php if ($login) { ?>
	
	<li class="nav-header">Administratie</li>
	<li><?php echo $this->html->link('Gebruikers', '/users'); ?>
	<li><?php echo $this->html->link('Gebruiker toevoegen', '/users/add'); ?></li>
	<?php }?>
</ul>
