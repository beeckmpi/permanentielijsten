 <script>
$(function() {
	$('.datepicker').datepicker({ dateFormat: 'dd-mm-yy' });
});
</script>
<?php echo $this->form->create($product, array('class' => 'no-shadow', 'id' => 'add_product_form', 'name' => 'add_product_form')); ?>
	<?php echo $this->form->field('tagnummer', array('label' => 'Tagnummer', 'required' => 'true', 'placeholder' => 'Tagnummer', 'size' => 10)); ?>	
 	<?php $types = array(
	  				'' 			=> '--Selecteer--', 
	   				'laptop' 	=> 'Laptop', 
	   				'desktop'	=> 'desktop', 
	   				'scherm' 	=> 'Scherm', 
	   				'printer' 	=> 'printer', 
			);
		?>
	<?php echo $this->form->field('type', array('label' => 'Type', 'required' => true, 'list' => $types, 'type' => 'select', 'style' => 'width: 140px;')); ?>	
	<?php echo $this->form->field('component', array('label' => 'Component', 'required' => 'true', 'placeholder' => 'Component', 'size' => 30)); ?>
	<?php echo $this->form->field('In dienst name', array('label' => 'In dienst name', 'required' => 'true', 'placeholder' => 'In dienst name', 'type' =>'date', 'size' => 10, 'class' => 'datepicker')); ?>
	<?php echo $this->form->field('locatie', array('label' => 'Locatie', 'required' => true, 'list' => $locaties, 'type' => 'select', 'style' => 'width: 220px;')); ?>
<?php echo $this->form->end(); ?>