<h2>Districten toevoegen</h2>
<?php echo $this->form->create($location, array('id' => 'locations', 'class' => '')); ?>
	<?php echo $this->form->field('district', array('label' => 'District', 'required' => 'true', 'placeholder' => 'District', 'size' => 50)); ?>	
	<?php echo $this->form->field('districtnummer', array('label' => 'Districtnummer', 'required' => 'true', 'placeholder' => 'Districtnummer', 'size' => 50)); ?>	
	<?php $locaties = array(
			        		'' 		=> '--Selecteer--', 
			        		'AWVA' 	=> 'Antwerpen', 
			        		'AWVB' 	=> 'Brussel', 
			        		'AWVL' 	=> 'Limburg', 
			        		'AWVOV' => 'Oost-Vlaanderen', 
			        		'PCO' 	=> 'PCO', 
			        		'AWVVB' => 'Vlaams Brabant', 
			        		'AWVWV' => 'West-Vlaanderen'
								);
			?>
	<label for="provincie">Provincie</label>
	<select name="provincie" required="true" style="width: 220px;">
		<?php foreach ($locaties as $key => $value) { ?>
			<option value="<?php echo $h($key); ?>"><?php echo $h($value); ?></option>			
		<?php } ?>		
	</select>
	<?php echo $this->form->field('telefoonnummer', array('label' => 'Telefoonnummer', 'required' => 'true', 'placeholder' => 'Telefoonnummer', 'size' => 50)); ?>	
	<?php echo $this->form->field('doorschakelnummer', array('label' => 'Doorschakelnummer', 'placeholder' => 'Doorschakelnummer', 'size' => 75)); ?>	
	
	<?php echo $this->form->submit('District toevoegen', array('id' => 'locatie_toevoegen')); ?>
	
<?php echo $this->form->end(); ?>