<h2>Wachtwoord Bewerken</h2>
    <?php echo $this->form->create($user); ?>
    	<div class="left-form">    		
    		<?php echo $this->form->field('username', array('type' => 'hidden', 'value' => $user->username)); ?>
	        <?php echo $this->form->field('password', array('label' => 'Oud wachtwoord', 'placeholder' => 'Wachtwoord', 'type' => 'password', 'size' => 50)); ?>
	        <div style="position:relative">
	        <?php echo $this->form->field('new_password', array('label' => 'Nieuw wachtwoord', 'placeholder' => 'Nieuw wachtwoord', 'type' => 'password', 'size' => 50)); ?>
	        <?php echo $this->form->field('repeat_password', array('label' => 'Nieuw wachtwoord herhalen', 'placeholder' => 'Nieuw wachtwoord herhalen', 'type' => 'password', 'size' => 50)); ?>
	        <div id="passwordOkText" class="error-msg"></div></div>
	        <?php echo $this->form->field('password_ok', array('type' => 'hidden', 'value' => '1')); ?>
        </div>
        <?php echo $this->form->submit('Wachtwoord Bewerken', array('id' => 'wachtwoord_bewerken')); ?>        
    <?php echo $this->form->end(); ?>