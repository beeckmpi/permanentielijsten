<h2>Werkaanvraag toevoegen</h2>
    <?php echo $this->form->create($werkaanvraag, array('id' => 'werkaanvraag_toevoegen_form')); ?>
	    <?php echo $this->form->field('titel', array('label' => 'Titel', 'required' => 'true', 'placeholder' => 'titel', 'size' => 50)); ?>
	    <?php echo $this->form->field('Werkaanvraag', array('type' => 'textarea', 'cols' => '120', 'rows' => '10', 'class' => 'ckeditor')); ?>	
	    <div>&nbsp;</div>  
        <?php echo $this->form->submit('werkaanvraag aanmaken', array('id' => 'werkaanvraag_toevoegen')); ?>        
    <?php echo $this->form->end(); ?>