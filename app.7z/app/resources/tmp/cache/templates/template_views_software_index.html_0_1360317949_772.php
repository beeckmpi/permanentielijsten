<h2>Software</h2>
<div class="add-button"><?php echo $this->html->link('+ software toevoegen', '/software/add'); ?></div>
<section>
	<?php foreach ($softwares as $software) { ?>
		<article class="software">
		   	<div class="naam item"><?php echo $h($software->naam); ?></div>
		   	<?php foreach ($files as $file) { ?>
		   		<?php if ($file->software_id == $software->_id) {?>
		   		<div class="label">Download:</div><div class="download item"><?php echo $this->html->link($file->filename, '/download/'.$file->filename); ?> <?php echo number_format($file->length / 1000000, 0);?>MB</div>
		   		<?php } ?>
		   	<?php } ?>
		   	<div class="label">Beschrijving:</div><div class="beschrijving item"><?php echo $software->beschrijving; ?></div>
		   	
		</article>
	<?php } ?>
</section>