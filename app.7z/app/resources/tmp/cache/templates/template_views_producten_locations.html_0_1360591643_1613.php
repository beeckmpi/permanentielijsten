<h2>Locaties</h2>
<?php echo $this->form->create($location, array('action' => 'locations/add', 'id' => 'locations', 'class' => 'form-horizontal')); ?>
	<input type="text" name="locatie" placeholder="locatie" size="50" />
   
	<?php $locaties = array(
			        		'' 		=> '--Selecteer--', 
			        		'AWVA' 	=> 'Antwerpen', 
			        		'AWVB' 	=> 'Brussel', 
			        		'AWVL' 	=> 'Limburg', 
			        		'AWVOV' => 'Oost-Vlaanderen', 
			        		'PCO' 	=> 'PCO', 
			        		'AWVVB' => 'Vlaams Brabant', 
			        		'AWVWV' => 'West-Vlaanderen'
								);
			?>
	<select name="provincie" required="true" style="width: 340px;">
		<?php foreach ($locaties as $key => $value) { ?>
			<option value="<?php echo $h($key); ?>"><?php echo $h($value); ?></option>			
		<?php } ?>		
	</select>
	
	<?php echo $this->form->submit('Locatie toevoegen', array('id' => 'locatie_toevoegen')); ?>
	
<?php echo $this->form->end(); ?>
    <table id="users_table">
    	<thead>
    		<tr>
	    		<th>Locatie</th>
	    		<th>Provincie</th>
	    		<th width="5%">Actief</th>
	    		<th width="5%">&nbsp;</th>
    		</tr>
    	</thead>
    	<tbody>
    		 <?php foreach ($locations as $locatie) { ?>
    		 	<?php 
    		 		if($locatie->actief == 'ja'){
    		 			$activeren = 'deactiveren';
    		 		} else {
    		 			$activeren = 'activeren';
    		 		}
				?>
	            <tr><td><?php echo $h($locatie->locatie); ?></td><td><?php echo $h($locatie->provincie); ?></td><td><?php echo $h($locatie->actief); ?></td><td><?php echo $this->html->link($activeren, '/producten/locaties/'.$activeren.'/'.$locatie->_id); ?></td></tr>
	        <?php } ?>
    	</tbody>
    </table>