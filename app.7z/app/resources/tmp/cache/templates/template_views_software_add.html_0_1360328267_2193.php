<?php echo $this->html->script('jquery.form.js')?>

<h2>Software toevoegen</h2>
    <?php echo $this->form->create($software, array('type' => 'file', 'id' => 'upload_form')); ?>
 		
 		<?php echo $this->form->field('naam', array('label' => 'Naam', 'required' => 'true', 'placeholder' => 'Naam', 'size' => 50)); ?>
 		<div style="display:inline-block; vertical-align: top">
 			<?php echo $this->form->field('myfile[]', array('label' => 'Bestand', 'type' => 'file', 'placeholder' => 'Naam', 'multiple' => 'multiple')); ?>
 		</div>
 		
	    <div id="status"></div>
	    <?php echo $this->form->field('beschrijving', array('type' => 'textarea', 'cols' => '120', 'rows' => '10', 'class' => 'ckeditor')); ?>
 		<div>&nbsp;</div>
        <?php echo $this->form->submit('Software Toevoegen', array('id' => 'software_toevoegen')); ?>
        
    <?php echo $this->form->end(); ?>
    <div id="progress_field" style="display:none">
    	De software wordt momenteel naar de server getransfereerd, gelieve dit venster niet te verlaten.
    	<div class="progress">
	        <div class="bar"></div >
	        <div class="percent">0%</div >
	    </div>
    </div>
    
<script>
	(function() {
    
	var bar = $('.bar');
	var percent = $('.percent');
	var status = $('#status');
	var SoftwareBeschrijving = document.getElementById('SoftwareBeschrijving');	
	$('form').ajaxForm({
		beforeSerialize: function($form, options) {
			CKupdate();
		},
	    beforeSend: function() {
	        status.empty();
	        var percentVal = '0%';
	        bar.width(percentVal)
	        percent.html(percentVal);
	        $('#upload_form').hide();
	        $('#progress_field').css('display', 'inherit');
	    },
	    uploadProgress: function(event, position, total, percentComplete) {
	        var percentVal = percentComplete + '%';
	        bar.width(percentVal)
	        percent.html(percentVal);
			//console.log(percentVal, position, total);
	    },
		complete: function(xhr) {
			status.html(xhr.responseText);
		},
		dataType: "json"
	}); 	
	})(); 
	
</script>
<script>
	function CKupdate(){
    for ( instance in CKEDITOR.instances )
        CKEDITOR.instances[instance].updateElement();
	}
</script>