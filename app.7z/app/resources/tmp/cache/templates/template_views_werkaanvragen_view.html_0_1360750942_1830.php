<section id="user-view" class="shadow" style="position:relative">
<h5>Werkaanvraag</h5>
<button class="btn status">Status: <?php echo $h($werkaanvraag->status); ?></button>
<div id="goedkeuringsvenster" class="popover fade bottom in"><div class="popover-content">
	<?php $status = array(
	        				'' 				=> '--Selecteer--', 
	        				'Goedgekeurd' 	=> 'Goedgekeurd', 
	        				'Afgekeurd'		=> 'Afgekeurd',
						);
	?>
   <?php echo $this->form->field('status', array('label' => 'Status', 'required' => true, 'list' => $status, 'type' => 'select')); ?>
   <?php echo $this->form->field('Opmerkingen', array('type' => 'textarea', 'cols' => '40', 'rows' => '4', 'class' => 'ckeditor')); ?>
   <div>&nbsp;</div>  
   <?php echo $this->form->submit('Status opslaan', array('id' => 'status_opslaan')); ?> 
   <?php echo $this->form->end(); ?></div>
</div>
<article class="werkaanvraag-geg">
	<?php if ($login['rol'] == 'administrator' || ($login['voornaam'].' '.$login['achternaam']) == $werkaanvraag->gebruiker){ ?>
	<div class="edit-article"><?php echo $this->html->link($this->html->image('icon-edit.png'), '/werkaanvraag/edit/'.$werkaanvraag->_id, array('escape' => false)); ?></div>
	<?php }?>
	<div id="werkaanvraag-title"><?php echo $h($werkaanvraag->titel); ?></div>
	<p style="font-size:smaller">Aangemaakt door <b><?php echo $h($werkaanvraag->gebruiker); ?></b> op <i><?php echo $h(date('d-m-Y H:i', $werkaanvraag->created->sec)); ?></i></p>
	<div id="werkaanvraag-tekst"><?php echo $werkaanvraag->Werkaanvraag;?></div>
</article>
<div>&nbsp;</div>
<?php echo $this->form->create($werkaanvraag, array('id' => 'werkaanvraag_bewerken_form', 'action' => 'edit/'.$werkaanvraag->_id)); ?>
	<?php echo $this->form->submit('Annuleren', array('id' => 'wijzigingen_annuleren')); ?> 
	<?php echo $this->form->submit('wijzigingen Opslaan', array('id' => 'wijzigingen_opslaan')); ?>
<?php echo $this->form->end(); ?>
</section>