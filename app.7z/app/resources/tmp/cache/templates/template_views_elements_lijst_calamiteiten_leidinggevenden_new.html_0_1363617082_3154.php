<div class="btn-group" style="float:right">
	    <a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
	    Exporteren
	    <span class="caret"></span>
	    </a>
	    <ul class="dropdown-menu">
			<li>
				<a href="#">CSV</a>
			</li>
			<li>
				<a href="#">MS Word</a>
			</li>
			<li>
				<a href="#">HTML</a>
			</li>
	    </ul>
	    <a class="btn" href="#">Lijst opslaan</a>
    </div>
    
<h3>Permanentielijst <?php echo $h($lijsten->type); ?> <?php echo $h($lijsten->subtype); ?> (<?php echo $h(date('Y',$lijsten->Startdatum->sec)); ?>-<?php echo $h(date('Y',$lijsten->Einddatum->sec)); ?>)</h3>
    
    <div style="clear:both"></div>
    <div class="row">
    	<div class="span4">
    		<div data-spy="affix" data-offset-top="0">
	    		<ul id="werknemers">	
	    			<?php foreach($personeel as $key){?>
	    				<?php if($key['GSM'] != ''){?>
	    					<li class="drag well" draggable="true"><span class="icon-move"></span>&nbsp;<span class="naam"><?php echo $h($key['naam']); ?></span><span class="icon-remove-sign"></span><span class="icon-pencil"></span><a class="icon-info-sign" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="<?php echo $h($key['GSM']); ?>"></a><div class="hidden GSM"><?php echo $h($key['GSM']); ?></div></li>
	    				<?php } else {?>
	    					<li class="drag well" draggable="true"><span class="icon-move"></span>&nbsp;<span class="naam"><?php echo $h($key['naam']); ?></span><span class="icon-remove-sign"></span><span class="icon-pencil"></span></li>
	    			<?php }} ?>								
				</ul>
				<div id="wn_toevoegen">
					<form id="wn_form">
					<input type="text" id="personeel" placeholder="Naam toevoegen" name="naam" val=""><br />
					<input type="text" id="GSM" placeholder="GSM nummer toevoegen" name="gsmnummer" val="">
					<input type="submit" value="toevoegen" id="personeel_toevoegen" class="btn">
					</form>
				</div>
			</div>
    	</div>
		<div class="span8">	
			
			<table>
				<thead>
					<tr>
						<th>Week</th>
						<th>Van</th>
						<th>Tot</th>
						<th>Naam leidinggevende</th>
						<th>GSM nummer</th>
					</tr>
					
				</thead>
				<tbody>
					<?php
						$year = date('Y',$lijsten->Startdatum->sec);
			    		$i = date('W', $lijsten->Startdatum->sec);
			    		$eind_week = date('W', $lijsten->Einddatum->sec);
			    		if ($i == $eind_week)
			    		{
			    			$eind_week--;
			    		}
			    		
			    		while ($i != $eind_week){
			    			if ($i <=9) {
			    				$digit = '0';
			    			} else {
			    				$digit = '';
			    			}
							if($i%2){
								echo '<tr style="BACKGROUND: #c4e0ff" id="week_'.$i.'"><td class="week">'.$i.'</td>';
							} else {
								echo '<tr id="week_'.$i.'"><td>'.$i.'</td>';
							}
							$y = $i;
							$y++;
							echo '<td class="van">'.date('d/m/Y', strtotime($year."W".$digit.$i)).'</td>';
							echo '<td class="tot">'.date('d/m/Y', strtotime($year."W".$digit.$y)).'</td><td class="leidingevende naam"></td><td class="leidingevende GSM"></td></tr>';
							
							if ($i == 52){
								$i = 0;
								$year = 2013;
							}
							$i++;
			    		}
					?>
				</tbody>
			</table>
		</div>
		
		</div>