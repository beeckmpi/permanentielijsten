<div class="btn-group" style="float:right">
	    <a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
	    Exporteren
	    <span class="caret"></span>
	    </a>
	    <ul class="dropdown-menu">
			<li>
				<a href="#">CSV</a>
			</li>
			<li>
				<a href="#">MS Word</a>
			</li>
			<li>
				<a href="#">HTML</a>
			</li>
	    </ul>
	    <a class="btn" href="#">Lijst opslaan</a>
    </div>
    
<h3>Permanentielijst</h3>
    
    <div style="clear:both"></div>
    <div class="row">
    	<div class="span4">
    		<div data-spy="affix" data-offset-top="0">
	    		<ul id="werknemers">							
				</ul>
				<div id="wn_toevoegen">
					<form id="wn_form">
					<input type="text" id="personeel" placeholder="Naam toevoegen" name="naam" val="">
					<input type="submit" value="toevoegen" id="personeel_toevoegen" class="btn">
					</form>
				</div>
			</div>
    	</div>
		<div class="span8">	
			
			<table>
				<thead>
					<tr>
						<th>Week</th>
						<th>Van</th>
						<th>Tot</th>
						<th>Wegentoezichters</th>
						<th>Arbeiders</th>
					</tr>
					
				</thead>
				<tbody>
					<?php
						$year = 2012;
			    	//	for($i=42; $i<=17; $i++){//
			    		$i = 43;
			    		while ($i != 42){
			    			if ($i <=9) {
			    				$digit = '0';
			    			} else {
			    				$digit = '';
			    			}
							if($i%2){
								echo '<tr style="BACKGROUND: #c4e0ff"><td>'.$i.'</td>';
							} else {
								echo '<tr><td>'.$i.'</td>';
							}
							$y = $i;
							$y++;
							echo '<td>'.date('d/m/Y', strtotime($year."W".$digit.$i)).'</td>';
							echo '<td>'.date('d/m/Y', strtotime($year."W".$digit.$y)).'</td><td class="wegentoezichters-vroeg naam"></td><td class="arbeiders-vroeg naam"></td></tr>';
							
							if ($i == 52){
								$i = 0;
								$year = 2013;
							}
							$i++;
			    		}
					?>
				</tbody>
			</table>
		</div>
		
		</div>