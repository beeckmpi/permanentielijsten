<?php echo $h(print_r($data)); ?>
<?php echo $h(print_r($permanentie)); ?>
