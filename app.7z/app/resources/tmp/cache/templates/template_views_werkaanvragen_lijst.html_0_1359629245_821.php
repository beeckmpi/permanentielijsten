<h2 >Werkaanvragen</h2>
<div class="add-button"><?php echo $this->html->link('+ Werkaanvraag toevoegen', '/werkaanvragen/add'); ?></div>

    <table id="users_table">
    	<thead>
    		<tr>
	    		<th>Datum</th>
	    		<th>Werkaanvraag</th>
	    		<th>Status</th>
    		</tr>
    	</thead>
    	<tbody>
    		 <?php foreach ($werkaanvragen as $werkaanvraag) { ?>
	            <tr>
	            	<td><?php echo $this->html->link(date('d-m-Y H:i', $werkaanvraag->created->sec), '/werkaanvragen/view/'.$werkaanvraag->_id); ?></td>
	            	<td><?php echo $this->html->link($werkaanvraag->titel, '/werkaanvragen/view/'.$werkaanvraag->_id); ?></td>
	            	<td><?php echo $this->html->link($werkaanvraag->status, '/werkaanvragen/view/'.$werkaanvraag->_id); ?></td>
	            </tr>
	        <?php } ?>
    	</tbody>
    </table>